import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { UpdateUserStoryRequest } from '../../../../models/update-userstory-request.model';
import { UserStories } from '../../../../models/userstory.model';

import { BacklogService } from '../../../../services/backlog.service';

@Component({
  selector: 'app-updateuserstory',
  templateUrl: './updateuserstory.component.html',
  styleUrl: './updateuserstory.component.css'
})
export class UpdateuserstoryComponent implements OnInit{
  id : number =0;
  userstory?: UserStories;
  
  constructor(private router: Router, private service : BacklogService){
  
  }
  ngOnInit(): void {
  }
  
  
a:number=0;
  OnSubmit(){
    console.log(this.id);
    this.service.getUserStoryByUserId(this.id).subscribe(
      (data) => {
        if(data != null){
          console.log(data);
          this.a=1;
          this.userstory = data;
        }

        
      },
      (error)=>{
        this.a=2;
        console.log(error);
      }
    );
  }
 

  onFormSubmit(): void{
     const updateUserStoryRequest: UpdateUserStoryRequest={
        status : this.userstory.status  ?? ''
        
        
    };
    
    
    if(this.id){
      this.service.updateuserstory(this.id,updateUserStoryRequest)
         .subscribe({
            next: (response) =>{
                alert('changes updated successfully');
                this.router.navigateByUrl('/home');
            } 
         });
  }
}  

}
