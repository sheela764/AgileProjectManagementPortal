import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewuserstorieslistComponent } from './viewuserstorieslist.component';

describe('ViewuserstorieslistComponent', () => {
  let component: ViewuserstorieslistComponent;
  let fixture: ComponentFixture<ViewuserstorieslistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewuserstorieslistComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ViewuserstorieslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
