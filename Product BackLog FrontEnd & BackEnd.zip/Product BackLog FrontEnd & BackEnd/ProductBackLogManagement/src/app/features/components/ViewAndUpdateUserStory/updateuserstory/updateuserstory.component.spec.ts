import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateuserstoryComponent } from './updateuserstory.component';

describe('UpdateuserstoryComponent', () => {
  let component: UpdateuserstoryComponent;
  let fixture: ComponentFixture<UpdateuserstoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdateuserstoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UpdateuserstoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
