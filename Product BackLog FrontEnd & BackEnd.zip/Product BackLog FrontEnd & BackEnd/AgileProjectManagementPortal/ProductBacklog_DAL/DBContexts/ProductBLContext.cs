﻿using Microsoft.EntityFrameworkCore;
using ProductBacklog_DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklog_DAL.DBContexts
{
    public class ProductBLContext :  DbContext    {
        public ProductBLContext() { }

        public ProductBLContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Epic> Epics { get; set; }

        public DbSet<UserStories> userStories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Epic>().HasKey(e => e.Id);

            modelBuilder.Entity<Epic>().Property(e => e.Id).IsRequired();

            modelBuilder.Entity<Epic>()
                 .Property(e => e.CreatedOn)
                 .HasColumnType("date")
                 .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<Epic>()
                  .Property(e => e.CompletedOn)
                  .HasColumnType("date");

            modelBuilder.Entity<Epic>()
                .Property(e => e.Status)
                .HasDefaultValue("Inprogress");

            modelBuilder.Entity<UserStories>()
              .Property(e => e.DoneOn)
              .HasColumnType("date");

            modelBuilder.Entity<UserStories>()
              .Property(e => e.CreatedOn)
              .HasColumnType("date")
              .HasDefaultValueSql("GETDATE()");

            

            modelBuilder.Entity<UserStories>()
                .Property(u => u.Status)
                .HasDefaultValue("New");


            modelBuilder.Entity<UserStories>()
            .HasOne(typeof(Epic))
            .WithMany()
            .IsRequired()
            .HasForeignKey("EpicId");

        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=LTIN238112;Initial Catalog=ProductBackLogDB;TrustServerCertificate=True;Integrated Security=SSPI;");
            base.OnConfiguring(optionsBuilder);
        }
    }
}

