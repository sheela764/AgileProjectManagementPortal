﻿using DummyProject_BAL.DTO;
using ProducBackLog_BAL.UserStoriesDTO;
using ProductBackLog_BAL.DTO;
using ProductBackLog_BAL.EpicsDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProducBackLog_BAL.Services
{
    public interface IProjectService
    {
        public async Task<int?> AddNewEpicToProject(EpicDTO epicDto) { return null; }

        public async Task<int?> AddUserStoryForEpic(int epicId, UserStoryDTO userStoryDTO) { return null; }

        public async Task<IList<UserStoryDTO>> GetDeveloperUserStory(string assignedDeveloperId) { return null; }

        public async Task<bool> UpdateUserStoryStatus(int id, UpdateUserStoryRequestDTO updateUserStortRequestDTO) { return false; }

        public async Task<List<ProductBackLogReportDTO>> GetReportBasedOnProjectCode(int ProjectCode) {  return null; }

        public async Task<UserStoryDTO> GetUserStoryByUserId(int Id) { return null; }

        public async Task<EpicDTO> GetEpicDetails(int epicId) { return null; }

        public bool ValidateUserStory(UserStoryDTO userStoryDTO) { return false; }





    }
}
