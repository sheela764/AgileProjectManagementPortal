import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Report } from '../../../models/report.model';
import { UserStories } from '../../../models/userstory.model';
import { BacklogService } from '../../../services/backlog.service';

@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrl: './generate-report.component.css'
})
export class GenerateReportComponent {
  Id : number =0;
  userstory?: UserStories;
  report : Report;
  ProjectCode: number=0;
  
  constructor(private router: Router, private service : BacklogService){
  
  }
  a:number=0;
  OnSubmit(){
    console.log(this.ProjectCode);
    this.service.getReport(this.ProjectCode)
    .subscribe(
      (data) => {
        // this.report = data;
        if(data){
          console.log(data);
          this.a=1
          this.report= data;
        }
        
      },
      (error)=>{
        this.a=2
      }
    );
  }
  getStatusCounts(stage: any): { status: string; count: number }[] {
    const statusCounts: { status: string; count: number }[] = [];
    for (const key in stage) {
      if (stage.hasOwnProperty(key)) {
        statusCounts.push({ status: key, count: stage[key] });
      }
    }
    return statusCounts;
  }

}
