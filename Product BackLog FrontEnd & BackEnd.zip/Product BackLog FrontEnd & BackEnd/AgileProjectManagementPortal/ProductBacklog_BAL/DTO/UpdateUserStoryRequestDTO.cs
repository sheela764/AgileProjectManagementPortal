﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBackLog_BAL.DTO
{
    public class UpdateUserStoryRequestDTO
    {
        public string Status { get; set; }
    }
}
