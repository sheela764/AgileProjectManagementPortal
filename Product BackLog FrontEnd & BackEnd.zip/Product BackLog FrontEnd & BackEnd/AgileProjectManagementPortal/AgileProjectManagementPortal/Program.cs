using Microsoft.AspNetCore.Components.Forms;
using Microsoft.EntityFrameworkCore;
using ProductBacklog_BAL.Repository;
using ProductBacklog_DAL.DBContexts;
using ProducBackLog_BAL.Services;
using ProductBackLog_BAL.Services;
using ProductBackLog_BAL.Mapper;
public class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.

        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();

        builder.Services.AddDbContext<ProductBLContext>(o => o.UseSqlServer(builder.Configuration.GetConnectionString("EPICConn")));

        builder.Services.AddScoped<IProjectService, ProjectService>();
        builder.Services.AddScoped<IProjectRepository, ProjectRepository>();

        builder.Services.AddAutoMapper(typeof(ProjectAutoMapper));

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseCors(options =>
        {
            options.AllowAnyHeader();
            options.AllowAnyOrigin();
            options.AllowAnyMethod();
        });

        app.UseAuthorization();

        app.MapControllers();

        app.Run();

    }
}
