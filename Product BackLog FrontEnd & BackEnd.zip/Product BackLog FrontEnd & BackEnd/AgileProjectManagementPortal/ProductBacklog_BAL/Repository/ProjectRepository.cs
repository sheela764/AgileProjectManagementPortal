﻿using ProductBacklog_DAL.DBContexts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Transactions;
using AutoMapper;
using static System.Formats.Asn1.AsnWriter;
using ProductBackLog_BAL.EpicsDTO;
using ProductBacklog_DAL.Model;
using ProducBackLog_BAL.UserStoriesDTO;
using ProductBackLog_BAL.DTO;

namespace ProductBacklog_BAL.Repository
{
    public class ProjectRepository : IProjectRepository
    {
        private readonly ProductBLContext _dbContext;
        private readonly IMapper _mapper;
        public ProjectRepository(ProductBLContext dbContext, IMapper mapper)
        {

            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }


        public async Task<int> AddEpic(EpicDTO epicDto)
        {
            try
            {
                var epic = _mapper.Map<Epic>(epicDto); // Map DTO to model
                await _dbContext.Epics.AddAsync(epic);
                await _dbContext.SaveChangesAsync();
                return epic.Id;
            }
            catch (Exception e)
            {
                return 0;
            }
        }

        public List<UserStoryDTO> GetstoryList(string developerId)
        {
            var stories = _dbContext.userStories
                    .Where(story => story.AssignedToDeveloperId == developerId)
                    .ToList();

            var storyDTOs = _mapper.Map<List<UserStoryDTO>>(stories);
            return storyDTOs;
        }



        public async Task<IList<UserStoryDTO>> GetUserStoryByDeveloperId(string developerId)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {

                var stories = await _dbContext.userStories
                    .Where(story => story.AssignedToDeveloperId == developerId)
                    .ToListAsync();

                var storyDTOs = _mapper.Map<List<UserStoryDTO>>(stories);
                scope.Complete();
                return storyDTOs;
            }
        }




        public async Task<bool> UpdateStoryStatusByUserId(int id, UpdateUserStoryRequestDTO updateUserStoryRequestDTO)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var story = await _dbContext.userStories.Where(u => u.Id == id).SingleOrDefaultAsync();
                if (story != null)
                {
                    story.Status = updateUserStoryRequestDTO.Status;
                    _dbContext.Entry(story).State = EntityState.Modified;
                    await _dbContext.SaveChangesAsync();
                    scope.Complete();
                    return true;

                }
                scope.Complete();
                return false;
            }

        }

        public async Task<List<Epic>> GetProjectCodeFromEpic(int ProjectCode)
        {

            var epics = await _dbContext.Epics.Where(epic => epic.ProjectCode == ProjectCode).ToListAsync();
            return epics;

        }


        public async Task<UserStoryDTO> GetUserStoryByUsingUserId(int Id)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var stories = await _dbContext.userStories.Where(story => story.Id == Id).SingleOrDefaultAsync();
                var storyDTO = _mapper.Map<UserStoryDTO>(stories);
                scope.Complete();
                return storyDTO;
            }
        }


        public async Task<EpicDTO> GetIdFromEpic(int Id)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var epicdata = await _dbContext.Epics.Where(e => e.Id == Id).SingleOrDefaultAsync();
                var epic = _mapper.Map<EpicDTO>(epicdata);
                scope.Complete();
                return epic;
            }

        }

        public string? AssignUserStoryToDeveloper(string AssignedDeveloperId, List<UserStoryDTO> userStoryDTO)
        {
            var activeStatuses = new List<string> { "New", "Planning", "Coding", "Testing" };
            int activeUserStoriesCount = userStoryDTO.Count(us => us.AssignedToDeveloperId == AssignedDeveloperId && IsActiveStatus(us.Status));

            bool IsActiveStatus(string status)
            {
                // Define the statuses that are considered 'Active'
                var activeStatuses = new List<string> { "New", "Planning", "Coding", "Testing" };
                return activeStatuses.Contains(status);
            }

            if (activeUserStoriesCount < 5)
            {
                return AssignedDeveloperId;
            }
            else
            {
                return null;
            }

        }


    }
}









