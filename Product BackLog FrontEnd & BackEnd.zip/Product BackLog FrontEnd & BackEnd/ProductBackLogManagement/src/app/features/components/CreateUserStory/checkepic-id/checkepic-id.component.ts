import { Component } from '@angular/core';
import { AddEpic } from '../../../../models/epic.model';
import { UserStories } from '../../../../models/userstory.model';
import { BacklogService } from '../../../../services/backlog.service';

@Component({
  selector: 'app-checkepic-id',
  templateUrl: './checkepic-id.component.html',
  styleUrl: './checkepic-id.component.css'
})
export class CheckepicIdComponent {
  Id : number=0;
  epic ?: AddEpic;
  userstorymodel: UserStories;
  a:number=0;
       

  constructor(private service : BacklogService){
    
     this.userstorymodel = {
      id: 0,
      title: "",
      userStoryDetails: "",
      acceptanceCriteria : "",
      priority : "",
      createdOn: null,
      doneOn : null,
      storyPoints : 0,
      assignedToDeveloperId: "",
      status: "",
      epicId: 0
     }
   }
  

  OnSubmit(){
    console.log(this.Id);
    this.service.getEpicDetails(this.Id).subscribe(
      (data) => {
        console.log(data);
        if(data){
          this.a=1
          this.epic = data;
        }
        
      },error=>
          this.a =2 
      );
  }
}
