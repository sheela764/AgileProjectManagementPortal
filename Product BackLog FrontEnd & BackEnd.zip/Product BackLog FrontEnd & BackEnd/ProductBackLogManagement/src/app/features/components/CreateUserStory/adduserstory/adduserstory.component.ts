import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { UserStories } from '../../../../models/userstory.model';
import { BacklogService } from '../../../../services/backlog.service';

@Component({
  selector: 'app-adduserstory',
  templateUrl: './adduserstory.component.html',
  styleUrl: './adduserstory.component.css'
})
export class AdduserstoryComponent {
  model: UserStories;
  Id:number =0;
  today = new Date().toISOString().split('T')[0];
  tomorrow: string;
  constructor(private router :Router,private backlogservice : BacklogService){
    this.model = {
      id: 0,
      title: "",
      userStoryDetails: "",
      acceptanceCriteria : "",
      priority : "",
      createdOn: null,
      doneOn : null,
      storyPoints : 0,
      assignedToDeveloperId:"",
      status: "",
      epicId: 0
    }
    let date = new Date();
        date.setDate(date.getDate() + 1); // set the date to tomorrow
        let day = ("0" + date.getDate()).slice(-2); // zero-pad the day
        let month = ("0" + (date.getMonth() + 1)).slice(-2); // zero-pad the month
        let year = date.getFullYear();

        this.tomorrow = `${year}-${month}-${day}`;
  }

  

  onFormSubmit(){
     this.backlogservice.AddUserStory(this.model.epicId, this.model)
        .subscribe({
          next:(response) => {
           alert("User Story was Created");
           this.router.navigateByUrl('/home')
          }
        })
  }
}
