import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckepicIdComponent } from './checkepic-id.component';

describe('CheckepicIdComponent', () => {
  let component: CheckepicIdComponent;
  let fixture: ComponentFixture<CheckepicIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CheckepicIdComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CheckepicIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
