import { HttpClientModule, provideHttpClient, withFetch } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './core/component/navbar/navbar.component';
import { AddepicComponent } from './features/components/addepic/addepic.component';
import { CheckepicIdComponent } from './features/components/CreateUserStory/checkepic-id/checkepic-id.component';
import { AdduserstoryComponent } from './features/components/CreateUserStory/adduserstory/adduserstory.component';
import { UserstorieslistComponent } from './features/components/UserStorieslist/userstorieslist/userstorieslist.component';
import { ViewuserstorieslistComponent } from './features/components/UserStorieslist/viewuserstorieslist/viewuserstorieslist.component';
import { UpdateuserstoryComponent } from './features/components/ViewAndUpdateUserStory/updateuserstory/updateuserstory.component';
import { GenerateReportComponent } from './features/components/generate-report/generate-report.component';
import { HomeComponent } from './features/components/home/home.component';


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    AddepicComponent,
    CheckepicIdComponent,
    AdduserstoryComponent,
    UserstorieslistComponent,
    ViewuserstorieslistComponent,
    UpdateuserstoryComponent,
    GenerateReportComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [
    [provideHttpClient(withFetch())]
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
