﻿using AutoMapper;
using DummyProject_BAL.DTO;
using ProducBackLog_BAL.UserStoriesDTO;
using ProductBackLog_BAL.DTO;
using ProductBackLog_BAL.EpicsDTO;
using ProductBacklog_DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBackLog_BAL.Mapper
{
    public class ProjectAutoMapper : Profile
    {
        public ProjectAutoMapper()
        {
            CreateMap<Epic, EpicDTO>()
           .ForMember(epic => epic.Id, opt => opt.MapFrom(epics => epics.Id))
           .ForMember(epic => epic.ProjectCode, opt => opt.MapFrom(epics => epics.ProjectCode))
           .ForMember(epic => epic.SprintId, opt => opt.MapFrom(epics => epics.SprintId))
           .ForMember(epic => epic.Name, opt => opt.MapFrom(epics => epics.Name))
           .ForMember(epic => epic.CompletedOn, opt => opt.MapFrom(epics => epics.CompletedOn))
           .ForMember(epic => epic.Status, opt => opt.MapFrom(epics => epics.Status));

            CreateMap<UserStories, UserStoryDTO>()
             .ForMember(story => story.Title, opt => opt.MapFrom(stories => stories.Title))
             .ForMember(story => story.UserStoryDetails, opt => opt.MapFrom(stories => stories.UserStoryDetails))
             .ForMember(story => story.AcceptanceCriteria, opt => opt.MapFrom(stories => stories.AcceptanceCriteria))
             .ForMember(story => story.AssignedToDeveloperId, opt => opt.MapFrom(stories => stories.AssignedToDeveloperId))
             .ForMember(story => story.DoneOn, opt => opt.MapFrom(stories => stories.DoneOn))
             .ForMember(story => story.Priority, opt => opt.MapFrom(stories => stories.Priority))
             .ForMember(story => story.StoryPoints, opt => opt.MapFrom(stories => stories.StoryPoints))
             .ForMember(story => story.Status, opt => opt.MapFrom(stories => stories.Status))
             .ForMember(story => story.EpicId, opt => opt.MapFrom(stories => stories.EpicId));

            CreateMap<EpicDTO, Epic>()
           .ForMember(epics => epics.Id, opt => opt.MapFrom(epic => epic.Id))
           .ForMember(epics => epics.ProjectCode, opt => opt.MapFrom(epic => epic.ProjectCode))
           .ForMember(epics => epics.SprintId, opt => opt.MapFrom(epic => epic.SprintId))
           .ForMember(epics => epics.Name, opt => opt.MapFrom(epic => epic.Name))
           .ForMember(epics => epics.CompletedOn, opt => opt.MapFrom(epic => epic.CompletedOn))
           .ForMember(epics => epics.Status, opt => opt.MapFrom(epic => epic.Status));

            CreateMap<UserStoryDTO, UserStories>()
             .ForMember(stories => stories.Title, opt => opt.MapFrom(story => story.Title))
             .ForMember(stories => stories.UserStoryDetails, opt => opt.MapFrom(story => story.UserStoryDetails))
             .ForMember(stories => stories.AcceptanceCriteria, opt => opt.MapFrom(story => story.AcceptanceCriteria))
             .ForMember(stories => stories.AssignedToDeveloperId, opt => opt.MapFrom(story => story.AssignedToDeveloperId))
             .ForMember(stories => stories.DoneOn, opt => opt.MapFrom(story => story.DoneOn))
             .ForMember(stories => stories.Priority, opt => opt.MapFrom(story => story.Priority))
             .ForMember(stories => stories.StoryPoints, opt => opt.MapFrom(story => story.StoryPoints))
             .ForMember(stories => stories.Status, opt => opt.MapFrom(story => story.Status))
             .ForMember(stories => stories.EpicId, opt => opt.MapFrom(story => story.EpicId));

            CreateMap<UpdateUserStoryRequestDTO, UserStoryDTO>()
                .ForMember(story => story.Status, opt => opt.MapFrom(stories => stories.Status));


            CreateMap<UserStoryDTO, UpdateUserStoryRequestDTO>()
               .ForMember(stories => stories.Status, opt => opt.MapFrom(story => story.Status));

            CreateMap<EpicDTO, ProductBackLogReportDTO>()
                .ForMember(stories => stories.Name, opt => opt.MapFrom(story => story.Name));

            CreateMap<ProductBackLogReportDTO, EpicDTO>()
               .ForMember(stories => stories.Name, opt => opt.MapFrom(story => story.Name));
        }

    }
}
