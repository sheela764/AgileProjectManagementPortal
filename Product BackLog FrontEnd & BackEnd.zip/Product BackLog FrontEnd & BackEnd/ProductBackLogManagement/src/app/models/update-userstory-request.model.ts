export interface UpdateUserStoryRequest{
    status: string;
}