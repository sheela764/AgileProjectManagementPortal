﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace ProductBacklog_DAL.Model
{
    public class UserStories
    {
        
        public int Id { get; set; }

        public string Title { get; set; }

        public string UserStoryDetails { get; set; }

        public string AcceptanceCriteria { get; set; }

        public string Priority { get; set; }

        public DateTime CreatedOn { get; set; } = DateTime.Now;

        public DateTime DoneOn { get; set; }

        public string AssignedToDeveloperId { get; set; }


        
        public int StoryPoints { get; set; }

        public string Status { get; set; }

        public int EpicId { get; set; }
    }



}

 
