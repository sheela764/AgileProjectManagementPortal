export interface UserStories{
    id: number,
    title: string,
    userStoryDetails: string,
    acceptanceCriteria : string,
    priority : string,
    createdOn: Date,
    doneOn : Date,
    storyPoints : number,
    assignedToDeveloperId: string,
    status: string,
    epicId: number
}