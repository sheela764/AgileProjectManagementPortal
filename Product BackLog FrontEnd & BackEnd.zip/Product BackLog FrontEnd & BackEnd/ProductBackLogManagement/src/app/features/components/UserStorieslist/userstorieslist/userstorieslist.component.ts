import { Component } from '@angular/core';
import { UserStories } from '../../../../models/userstory.model';
import { BacklogService } from '../../../../services/backlog.service';

@Component({
  selector: 'app-userstorieslist',
  templateUrl: './userstorieslist.component.html',
  styleUrl: './userstorieslist.component.css'
})
export class UserstorieslistComponent {
    AssignedToDeveloperId : string ="";
  userstory?: UserStories[];
  errorMessage: any;

  constructor(private service : BacklogService){

  }
a:number=0;
  OnSubmit(){
    console.log(this.AssignedToDeveloperId);
    this.service.getUserStoryListByDeveloperId(this.AssignedToDeveloperId).subscribe(
      (data) => {
        if(data){
          this.a=1;
          console.log(data);
          this.userstory = data;
        }
        
      },
      (error)=>{
        this.a =2;
      }
    );
  }
}
