﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProducBackLog_BAL.Services;
using ProducBackLog_BAL.UserStoriesDTO;
using ProductBacklog_BAL.Repository;
using ProductBackLog_BAL.DTO;
using ProductBackLog_BAL.EpicsDTO;
using System.Collections.Generic;
using System.Transactions;

namespace AgileProjectManagementPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectRepository _projectRepository;
        private readonly IProjectService _projectService;

        public ProjectController(IProjectRepository projectRepository, IProjectService projectService)
        {
            _projectRepository = projectRepository;
            _projectService = projectService;
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] EpicDTO epicdto)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var epicID = await _projectService.AddNewEpicToProject(epicdto);
                    if (epicID == 0)
                    {
                        return BadRequest("The error is occured at the time of add the new epic");
                    }
                    scope.Complete();
                    return CreatedAtAction(nameof(Get), new { AssignedDeveloperId = epicID }, epicdto);
                }

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }

        [HttpPost("{epicId},Name=AddUserStory")]
        public async Task<IActionResult> PostUserStory(int epicId, [FromBody] UserStoryDTO userStoryDTO)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var story = await _projectService.AddUserStoryForEpic(epicId, userStoryDTO);
                    if (story == 0)
                    {
                        return BadRequest("The error is occured so you can't add the user story");
                    }
                    scope.Complete();
                    return CreatedAtAction(nameof(Get), new { AssignedDeveloperId = story }, userStoryDTO);
                }

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }

        [HttpGet("{AssignedDeveloperId}, Name=GetUserStoryByDevId")]
        public async Task<IActionResult> Get([FromRoute] string AssignedDeveloperId)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var userstory = await _projectService.GetDeveloperUserStory(AssignedDeveloperId);
                    if (userstory.Count == 0)
                    {
                        return BadRequest("The assigned developer id's are not get from the database");
                    }
                    scope.Complete();
                    return new OkObjectResult(userstory);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }


        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(int id, [FromBody]UpdateUserStoryRequestDTO updateUserStoryRequestDTO)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var success = await _projectService.UpdateUserStoryStatus(id, updateUserStoryRequestDTO);
                    if (!success)
                    {
                        return BadRequest("The status is not updated successful");
                    }
                    scope.Complete();
                    return new OkResult();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }

        [HttpGet("{ProjectCode}, Name=GetReportByProjectCode")]
        public async Task<IActionResult> GetReport(int ProjectCode)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var userstory = await _projectService.GetReportBasedOnProjectCode(ProjectCode);
                    if (userstory.Count == 0)
                    {
                        return BadRequest("The error is occured to generate the report");
                    }
                    scope.Complete();
                    return new OkObjectResult(userstory);

                }

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }


        }


        [HttpGet("{Id}, Name=GetUserStoryById")]
        public async Task<IActionResult> GetUserStory(int Id)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var userstory = await _projectService.GetUserStoryByUserId(Id);
                    if (userstory == null)
                    {
                        return BadRequest("The error is occured to get the user story");
                    }
                    scope.Complete();
                    return new OkObjectResult(userstory);

                }

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }

        }

        [HttpGet("{Id}, Name=GetEpicdetails")]
        public async Task<IActionResult> GetEpicDetailsById([FromRoute] int Id)
        {
            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var epic = await _projectService.GetEpicDetails(Id);
                    if (epic == null)
                    {
                        return BadRequest("The error is occured to get the epic details");
                    }
                    scope.Complete();
                    return new OkObjectResult(epic);
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }



    }
}
