﻿
using Microsoft.EntityFrameworkCore;
using ProducBackLog_BAL.UserStoriesDTO;
using ProductBackLog_BAL.DTO;
using ProductBackLog_BAL.EpicsDTO;
using ProductBacklog_DAL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ProductBacklog_BAL.Repository
{
    public interface IProjectRepository
    {
        public async Task<int> AddEpic(EpicDTO epicdto) { return 0; }

        public List<UserStoryDTO> GetstoryList(string developerId)
        {
            return null;
        }

        public async Task<EpicDTO> GetIdFromEpic(int epicId) { return null; }
        public async Task<IList<UserStoryDTO>> GetUserStoryByDeveloperId(string assignedDeveloperId) { return null; }

        public async Task<bool> UpdateStoryStatusByUserId(int id, UpdateUserStoryRequestDTO updateUserStoryRequestDTO) { return false; }

        public async Task<List<Epic>> GetProjectCodeFromEpic(int ProjectCode) { return null; }
        public async Task<UserStoryDTO> GetUserStoryByUsingUserId(int Id) { return null; }

        public string? AssignUserStoryToDeveloper(string AssignedDeveloperId, List<UserStoryDTO> userStoryDTO) { return null; }
        






        }
}
