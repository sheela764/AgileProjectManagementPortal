import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserstorieslistComponent } from './userstorieslist.component';

describe('UserstorieslistComponent', () => {
  let component: UserstorieslistComponent;
  let fixture: ComponentFixture<UserstorieslistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UserstorieslistComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserstorieslistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
