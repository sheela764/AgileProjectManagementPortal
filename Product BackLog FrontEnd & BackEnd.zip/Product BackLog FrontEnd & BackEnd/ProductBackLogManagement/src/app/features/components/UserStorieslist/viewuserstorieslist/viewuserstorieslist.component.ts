import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/internal/Subscription';
import { UserStories } from '../../../../models/userstory.model';
import { BacklogService } from '../../../../services/backlog.service';
import {Location} from '@angular/common'
@Component({
  selector: 'app-viewuserstorieslist',
  templateUrl: './viewuserstorieslist.component.html',
  styleUrl: './viewuserstorieslist.component.css'
})
export class ViewuserstorieslistComponent implements OnInit, OnDestroy{
  id: number|0=0;
  a:number=0;
  paramsSubscription: Subscription;
  userstory?: UserStories;
  constructor(private route: ActivatedRoute, private backlogservice: BacklogService,private location:Location){}
  
  ngOnInit(): void {
    this.route.paramMap.subscribe(
      {
        next: (params) => {
          const userid=params.get('id');
          if(userid != null)
          {
            this.id=parseInt(userid);
            if(this.id){
               this.backlogservice.getUserStoryByUserId(this.id)
               .subscribe({
                 next: (response) =>{
                     console.log(response);
                     this.userstory = response;
                }
               });
            }
          }

        }
      }
    )
  }
  goBack(){
    if (window.history.length > 1) {
    this.location.back();
    }
  }
 
  ngOnDestroy(): void {
     this.paramsSubscription?.unsubscribe();
  }
}
