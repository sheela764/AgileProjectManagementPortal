export interface AddEpic{
    Id: number,
    ProjectCode : number,
    SprintId : number,
    Name : string,
    CreatedOn : Date,
    CompletedOn : Date,
    Status : string
}