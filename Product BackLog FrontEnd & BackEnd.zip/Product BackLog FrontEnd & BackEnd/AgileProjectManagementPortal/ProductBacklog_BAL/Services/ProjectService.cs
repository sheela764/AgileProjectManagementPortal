﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using ProductBacklog_BAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Formats.Asn1.AsnWriter;
using System.Transactions;
using ProductBacklog_DAL.DBContexts;
using ProducBackLog_BAL.Services;
using ProductBacklog_DAL.Model;
using ProductBackLog_BAL.EpicsDTO;
using ProducBackLog_BAL.UserStoriesDTO;
using ProductBackLog_BAL.DTO;
using DummyProject_BAL.DTO;


namespace ProductBackLog_BAL.Services
{
    public class ProjectService : IProjectService
    {
        private readonly ProductBLContext _dbContext;
        private readonly IProjectRepository _projectRepository;
        private readonly IMapper _mapper;
        public ProjectService(IProjectRepository projectRepository,ProductBLContext dbContext, IMapper mapper)
        {
           
            _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public ProjectService(IProjectRepository projectRepository, ProductBLContext dbContext)
        {

            _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
            _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
            
        }


        //public ProjectService(ProductBLContext dbContext)
        //{
        //    _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        //}

        //public ProjectService(ProductBLContext dbContext, IProjectRepository projectRepository, IMapper mapper)
        //{
        //    _dbContext = dbContext ?? throw new ArgumentNullException(nameof(dbContext));
        //    _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
        //    _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        //}
        public async Task<int?> AddNewEpicToProject(EpicDTO epicDto)
        {
            var epic_id = await _projectRepository.AddEpic(epicDto);
            if(epic_id !=0 ) {
                return epic_id;
            }
            else
            {
                return 0;
            }
            
        }


        public async Task<int?> AddUserStoryForEpic(int epicId, UserStoryDTO userStoryDTO)
        {
            var epic = await _projectRepository.GetIdFromEpic(epicId);

            if (epic != null)
            {
                if (ValidateUserStory(userStoryDTO))
                {
                    var story = _mapper.Map<UserStories>(userStoryDTO); // Map DTO to model
                    var developerId = userStoryDTO.AssignedToDeveloperId;
                    var userStories = _projectRepository.GetstoryList(developerId);
                    var assigneddeveloperId = _projectRepository.AssignUserStoryToDeveloper(developerId, userStories);
                    if ( assigneddeveloperId != null)
                    {
                        await _dbContext.userStories.AddAsync(story);
                        await _dbContext.SaveChangesAsync();
                        return story.Id;
                    }
                    else { return 0; }

                }
                else { return 0; }
            }
            else
            {
                return 0;
            }
        }
        


        public async Task<IList<UserStoryDTO>> GetDeveloperUserStory(string assignedDeveloperId)
        {
            var story = await _projectRepository.GetUserStoryByDeveloperId(assignedDeveloperId);
            return story;
        }

        public async Task<bool> UpdateUserStoryStatus(int id, UpdateUserStoryRequestDTO updateUserStoryRequestDTO)
        {
            var status = await _projectRepository.UpdateStoryStatusByUserId(id, updateUserStoryRequestDTO);
            return status;
        }

        public async Task<List<ProductBackLogReportDTO>> GetReportBasedOnProjectCode(int ProjectCode)
        {
            var epics = await _projectRepository.GetProjectCodeFromEpic(ProjectCode);
            List<ProductBackLogReportDTO> reports = new List<ProductBackLogReportDTO>();

            foreach (var e in epics)
            {
                var epicReport = new ProductBackLogReportDTO
                {
                    Name = e.Name,
                    Stage = new Dictionary<string, int>()
                };

                var stories = await _dbContext.userStories.Where(story => story.EpicId == e.Id).ToListAsync();
                var groupedStories = stories.GroupBy(story => story.Status);

                foreach (var group in groupedStories)
                {
                    if (!string.IsNullOrEmpty(group.Key))
                    {
                        epicReport.Stage[group.Key] = group.Count();
                    }

                }

                reports.Add(epicReport);
            }

            return reports;
        }

               public async Task<UserStoryDTO> GetUserStoryByUserId(int Id)
               {
                  var userstory = await _projectRepository.GetUserStoryByUsingUserId(Id);
                  return userstory;
               }


        public bool  ValidateUserStory(UserStoryDTO userStoryDTO)
        {
            // Validate title, details, and acceptance criteria lengths
            bool isTitleValid = ValidateLength(userStoryDTO.Title, 10);
            bool areDetailsValid = ValidateLength(userStoryDTO.UserStoryDetails, 50);
            bool areCriteriaValid = ValidateLength(userStoryDTO.AcceptanceCriteria, 50);
            return isTitleValid && areDetailsValid && areCriteriaValid;
        }

        public bool ValidateLength(string text, int minLength)
        {
            return text.Length >= minLength;
        }

        public async Task<EpicDTO> GetEpicDetails(int Id)
        {
            var userstory = await _projectRepository.GetIdFromEpic(Id);
            return userstory;
        }



    }

}


