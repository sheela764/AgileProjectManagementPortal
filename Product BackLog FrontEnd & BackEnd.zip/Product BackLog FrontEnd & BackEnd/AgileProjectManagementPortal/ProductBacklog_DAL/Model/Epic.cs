﻿using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ProductBacklog_DAL.Model
{
    public class Epic
    {

        public int Id { get; set; }

        public int ProjectCode { get; set; }

        public int SprintId { get; set; }

        public string Name { get; set; }

        public DateTime CreatedOn { get; set; } = DateTime.Now;

        public DateTime CompletedOn { get; set; }

        public string Status { get; set; }
    }
}
