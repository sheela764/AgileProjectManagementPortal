import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddepicComponent } from './addepic.component';

describe('AddepicComponent', () => {
  let component: AddepicComponent;
  let fixture: ComponentFixture<AddepicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddepicComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddepicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
