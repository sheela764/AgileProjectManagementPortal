﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DummyProject_BAL.DTO
{
    public class ProductBackLogReportDTO
    {
        public string Name {  get; set; }

        public Dictionary<string, int> Stage { get; internal set; }
    }
}
