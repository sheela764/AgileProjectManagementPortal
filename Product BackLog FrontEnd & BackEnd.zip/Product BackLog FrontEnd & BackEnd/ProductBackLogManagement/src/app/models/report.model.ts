export interface Report{
    Name: string,
    status: string | null;
    count: number;
    stage: { [key: string]: number };
    
}