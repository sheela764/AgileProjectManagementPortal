﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductBackLog_BAL.EpicsDTO;

public class EpicDTO
{


    public int Id { get; set; }
    public int ProjectCode { get; set; }

    public int SprintId { get; set; }

    public string Name { get; set; }

    public DateTime CompletedOn { get; set; }
    public string Status { get; set; }

}

