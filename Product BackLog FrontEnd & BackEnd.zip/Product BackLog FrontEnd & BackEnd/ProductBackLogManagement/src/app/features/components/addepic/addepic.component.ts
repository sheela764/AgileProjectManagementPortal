import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AddEpic } from '../../../models/epic.model';
import { BacklogService } from '../../../services/backlog.service';

@Component({
  selector: 'app-addepic',
  templateUrl: './addepic.component.html',
  styleUrl: './addepic.component.css'
})
export class AddepicComponent {
     model : AddEpic;
     tomorrow: string;
     
     constructor(private route: Router, private backlogservice: BacklogService){
        this.model = {
          Id: 0,
          ProjectCode : 0,
          SprintId : 0,
          Name : '',
          CreatedOn : null,
          CompletedOn : null,
          Status : ''
        }
        let date = new Date();
        date.setDate(date.getDate() + 1); // set the date to tomorrow
        let day = ("0" + date.getDate()).slice(-2); // zero-pad the day
        let month = ("0" + (date.getMonth() + 1)).slice(-2); // zero-pad the month
        let year = date.getFullYear();

        this.tomorrow = `${year}-${month}-${day}`;
     }
     onFormSubmit(){
      this.backlogservice.AddEpic(this.model)
         .subscribe({
           next:(response) => {
            alert("epic was created");
           }
         })
   }
}
