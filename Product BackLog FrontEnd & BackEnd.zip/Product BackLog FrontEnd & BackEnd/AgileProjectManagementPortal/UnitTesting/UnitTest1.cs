using Moq;
using AutoMapper;
using ProductBacklog_BAL.Repository;
using ProducBackLog_BAL.Services;
using ProductBackLog_BAL.Mapper;
using ProductBackLog_BAL.Services;
using ProducBackLog_BAL.UserStoriesDTO;
using Microsoft.AspNetCore.Identity;
using ProductBacklog_DAL.Model;
using Microsoft.EntityFrameworkCore;
using ProductBacklog_DAL.DBContexts;
using ProductBackLog_BAL.EpicsDTO;
using ProductBackLog_BAL.DTO;
using DummyProject_BAL.DTO;
using System.Linq.Expressions;
using System.Linq;



namespace UnitTesting
{
    [TestFixture]
    public class Tests
    {
        private Mock<IProjectRepository> _mockrepository;
        private ProjectService _projectService;
        private ProjectService _productbacklog;
        private Mock<ProductBLContext> _dbContextMock;
        private IMapper _mapper;
        [SetUp]
        public void Setup()
        {
            if (_mapper == null)
            {
                var mappingConfig = new MapperConfiguration(
                    mc =>
                    {
                        mc.AddProfile(new ProjectAutoMapper());
                    });
                IMapper mappers = mappingConfig.CreateMapper();
                _mapper = mappers;
            }
            _dbContextMock = new Mock<ProductBLContext>();
            //_projectService = new ProjectService(_dbContextMock.Object);
            _mockrepository = new Mock<IProjectRepository>();
            _projectService = new ProjectService(_mockrepository.Object, _dbContextMock.Object);

        }

        //GetUserStoryByDeveloperId return success
        [Test]
        public async Task GetDeveloperUserStory_ShouldReturnUserStories()
        {
            // Arrange
            var assignedDeveloperId = "developer123";
            var expectedUserStories = new List<UserStoryDTO>
        {
            new UserStoryDTO { Id = 1, Title = "Story 1" },
            new UserStoryDTO { Id = 2, Title = "Story 2" }
        };
            _mockrepository.Setup(repo => repo.GetUserStoryByDeveloperId(assignedDeveloperId))
                .ReturnsAsync(expectedUserStories);

            // Act
            var result = await _projectService.GetDeveloperUserStory(assignedDeveloperId);

            // Assert
            Assert.AreEqual(expectedUserStories, result);
        }

        //GetUserStoryByDeveloperId return null
        [Test]
        public async Task GetDeveloperUserStory_ShouldReturnNullWhenNoUserStories()
        {
            // Arrange
            var assignedDeveloperId = "developer456";
            _mockrepository.Setup(repo => repo.GetUserStoryByDeveloperId(assignedDeveloperId))
                .ReturnsAsync((IList<UserStoryDTO>)null);

            // Act
            var result = await _projectService.GetDeveloperUserStory(assignedDeveloperId);

            // Assert
            Assert.IsNull(result);
        }

        //GetUserStoryByUserId return success 
        [Test]
        public async Task GetUserStoryByUserId_ShouldReturnUserStory()
        {
            // Arrange
            var userId = 123;
            var expectedUserStory = new UserStoryDTO { Id = 101, Title = "Story 1", EpicId = 1, Status = "To Do" };
            _mockrepository.Setup(repo => repo.GetUserStoryByUsingUserId(userId))
                .ReturnsAsync(expectedUserStory);

            // Act
            var result = await _projectService.GetUserStoryByUserId(userId);

            // Assert
            Assert.AreEqual(expectedUserStory, result);
        }

        //GetUserStoryByUserId return null
        [Test]
        public async Task GetUserStoryByUserId_ShouldReturnNullWhenNotFound()
        {
            // Arrange
            var userId = 456;
            _mockrepository.Setup(repo => repo.GetUserStoryByUsingUserId(userId))
                .ReturnsAsync((UserStoryDTO)null);

            // Act
            var result = await _projectService.GetUserStoryByUserId(userId);

            // Assert
            Assert.IsNull(result);
        }
        //GetEpicDetails return epic 
        [Test]
        public async Task GetEpicDetails_ShouldReturnEpic()
        {
            // Arrange
            var epicId = 123;
            var expectedEpic = new EpicDTO { Id = 1, Name = "Epic 1" };
            _mockrepository.Setup(repo => repo.GetIdFromEpic(epicId))
                .ReturnsAsync(expectedEpic);

            // Act
            var result = await _projectService.GetEpicDetails(epicId);

            // Assert
            Assert.AreEqual(expectedEpic, result);
        }
        //GetEpicDetails return null
        [Test]
        public async Task GetEpicDetails_ShouldReturnNullWhenNotFound()
        {
            // Arrange
            var epicId = 456;
            _mockrepository.Setup(repo => repo.GetIdFromEpic(epicId))
                .ReturnsAsync((EpicDTO)null);

            // Act
            var result = await _projectService.GetEpicDetails(epicId);

            // Assert
            Assert.IsNull(result);
        }

        //UpdateUserStory updated successfully return true 
        [Test]
        public async Task UpdateUserStoryStatus_ShouldReturnTrueWhenStatusUpdated()
        {
            // Arrange
            var userStoryId = 123;
            var updateRequest = new UpdateUserStoryRequestDTO { Status = "In Progress" };
            _mockrepository.Setup(repo => repo.UpdateStoryStatusByUserId(userStoryId, updateRequest))
                .ReturnsAsync(true);

            // Act
            var result = await _projectService.UpdateUserStoryStatus(userStoryId, updateRequest);

            // Assert
            Assert.IsTrue(result);
        }

        //UpdateUserStory updated successfully return false 
        [Test]
        public async Task UpdateUserStoryStatus_ShouldReturnFalseWhenStatusNotUpdated()
        {
            // Arrange
            var userStoryId = 456;
            var updateRequest = new UpdateUserStoryRequestDTO { Status = "In Progress" };
            _mockrepository.Setup(repo => repo.UpdateStoryStatusByUserId(userStoryId, updateRequest))
                .ReturnsAsync(false);

            // Act
            var result = await _projectService.UpdateUserStoryStatus(userStoryId, updateRequest);

            // Assert
            Assert.IsFalse(result);
        }

        //AddEpic Created Successfully 
        [Test]
        public async Task AddNewEpicToProject_ShouldReturnEpicIdWhenCreated()
        {
            // Arrange
            var epicDto = new EpicDTO { Name = "New Epic" };
            var expectedEpicId = 123;
            _mockrepository.Setup(repo => repo.AddEpic(epicDto))
                .ReturnsAsync(expectedEpicId);

            // Act
            var result = await _projectService.AddNewEpicToProject(epicDto);

            // Assert
            Assert.AreEqual(expectedEpicId, result);
        }

        //AddEpic failed 
        [Test]
        public async Task AddNewEpicToProject_ShouldReturnZeroWhenNotCreated()
        {
            // Arrange
            var epicDto = new EpicDTO { Name = "Invalid Epic" };
            _mockrepository.Setup(repo => repo.AddEpic(epicDto))
                .ReturnsAsync(0);

            // Act
            var result = await _projectService.AddNewEpicToProject(epicDto);

            // Assert
            Assert.AreEqual(0, result);
        }

        //AddUserStory for epic is created successfully
        [Test]
        public async Task AddUserStoryForEpic_ShouldReturnUserStoryIdCreated()
        {
            // Arrange
            var epicId = 5;
            var retEpic = new EpicDTO { Id = 5, Name = "authentication" };
            var userStoryDto = new UserStoryDTO { Title = "Invalid User Story", UserStoryDetails = "the username and password for required field as per business logic ", AcceptanceCriteria = "the username and password for required field as per business logic", AssignedToDeveloperId = "5" };
            var usDTO = new List<UserStoryDTO>();
            _mockrepository.Setup(repo => repo.GetIdFromEpic(epicId))
                .ReturnsAsync(retEpic);
            _mockrepository.Setup(x => x.GetstoryList(It.IsAny<string>())).Returns(usDTO);
            _mockrepository.Setup(y => y.AssignUserStoryToDeveloper(It.IsAny<string>(), It.IsAny<List<UserStoryDTO>>())).Returns("");

            var repos = _mockrepository.Object;

            Assert.IsNotNull(retEpic);

            bool retVal = _projectService.ValidateUserStory(userStoryDto);

            Assert.IsTrue(retVal);

            var story = _mapper.Map<UserStories>(userStoryDto);
            Assert.That(story, Is.Not.Null);
            Assert.IsNotNull(story.AssignedToDeveloperId);

            var userStories = repos.GetstoryList(story.AssignedToDeveloperId);

            Assert.IsNotNull(userStories);

            Assert.That(userStories.Count, Is.EqualTo(usDTO.Count));


            var assigneddeveloperId = repos.AssignUserStoryToDeveloper(story.AssignedToDeveloperId, userStories);

            Assert.IsNotNull(assigneddeveloperId);

            // Act
            Task<int?> result = _projectService.AddUserStoryForEpic(epicId, userStoryDto);

            // Assert
            Assert.IsNotNull(result);
        }

        //AddUserStory for epic not created successfully 
        [Test]
        public async Task AddUserStoryForEpic_ShouldReturnZeroWhenNotCreated()
        {
            // Arrange
            var epicId = 456;
            var userStoryDto = new UserStoryDTO { Title = "Invalid User Story", AssignedToDeveloperId = "developer123" };
            _mockrepository.Setup(repo => repo.GetIdFromEpic(epicId))
                .ReturnsAsync((EpicDTO)null);



            // Act
            var result = await _projectService.AddUserStoryForEpic(epicId, userStoryDto);

            // Assert
            Assert.AreEqual(0, result);
        }

 
        

        //[Test]
        //public async Task GetReportBasedOnProjectCode_ReturnsReport()
        //{
        //    Arrange
        //   var projectCode = 123;
        //    var epics = new List<Epic> { new Epic { Id = 1 }, new Epic { Id = 1 } };

        //    _mockrepository.Setup(repo => repo.GetProjectCodeFromEpic(projectCode))
        //        .ReturnsAsync(epics);

        //    Mock user stories for Epic 1

        //   var epic1Stories = new List<UserStories>
        //   {
        //        new UserStories { EpicId = 1, Status = "New" },
        //        new UserStories { EpicId = 1, Status = "Planning" },
        //        new UserStories { EpicId = 1, Status = "Done" }
        //   };

        //   _dbContextMock.Setup(db => db.userStories)
        //       .Returns((DbSet<UserStories>)MockDbSet(epic1Stories));

        //    Act

        //   var reports = await _projectService.GetReportBasedOnProjectCode(projectCode);

        //    Assert
        //    Assert.IsNotNull(reports);
        //    Assert.AreEqual(2, reports.Count);
        //    Assert.Equals(2, reports[0].Stage["New"]);
        //    Assert.Equals(1, reports[0].Stage["Planning"]);
        //}

        //private static DbSet<epic1Stories> MockDbSet<epic1Stories>(IEnumerable<epic1Stories> data) where epic1Stories : class
        //{
        //    var queryable = data.AsQueryable();
        //    var dbSetMock = new Mock<DbSet<epic1Stories>>();
        //    dbSetMock.As<IQueryable<epic1Stories>>().Setup(m => m.Provider).Returns(queryable.Provider);
        //    dbSetMock.As<IQueryable<epic1Stories>>().Setup(m => m.Expression).Returns(queryable.Expression);
        //    dbSetMock.As<IQueryable<epic1Stories>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
        //    dbSetMock.As<IQueryable<epic1Stories>>().Setup(m => m.GetEnumerator()).Returns(queryable.GetEnumerator());
        //    return dbSetMock.Object;
        //}



      // Get Report is not generate report
               [Test]
        public async Task GetReportBasedOnProjectCode_DoesNotCreateReport_WhenNoEpics()
        {
            // [Arrange]
            var projectCode = 123; // replace with an actual project code

            // Setup your mock objects and any necessary data
            var expectedEpics = new List<Epic>(); // No epics
            _mockrepository.Setup(repo => repo.GetProjectCodeFromEpic(projectCode)).ReturnsAsync(expectedEpics);

            // Act
            var result = await _projectService.GetReportBasedOnProjectCode(projectCode);

            // Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<List<ProductBackLogReportDTO>>(result);
           
            Assert.AreEqual(0, result.Count); // Expecting no reports
        }

        [Test]
        public async Task GetReportBasedOnProjectCode_Should_Return_Correct_Report()
        {
            // Arrange
            var projectCode = 123;
            var epicId1 = 1;
            var epicId2 = 2;
            var epicName1 = "Epic 1";
            var epicName2 = "Epic 2";
            var userStory1 = new UserStories { EpicId = epicId1, Status = "In Progress" };
            var userStory2 = new UserStories { EpicId = epicId1, Status = "Done" };
            var userStory3 = new UserStories { EpicId = epicId2, Status = "To Do" };

            // Create an IQueryable<UserStory> from the list
            var userStoriesList = new List<UserStories> { userStory1, userStory2, userStory3 };
            var userStoriesQueryable = userStoriesList.AsQueryable();

            _mockrepository.Setup(repo => repo.GetProjectCodeFromEpic(projectCode))
                .ReturnsAsync(new List<Epic>
                {
                    new Epic { Id = epicId1, Name = epicName1 },
                    new Epic { Id = epicId2, Name = epicName2 }
                });

            _dbContextMock.Setup(db => db.userStories)
                .Returns((DbSet<UserStories>)userStoriesQueryable);

            // Act
            var result = await _projectService.GetReportBasedOnProjectCode(projectCode);

            // Assert
            Assert.That(result, Is.Not.Null);
            Assert.That(result.Count, Is.EqualTo(2));

            var epicReport1 = result.FirstOrDefault(r => r.Name == epicName1);
            Assert.That(epicReport1, Is.Not.Null);
            Assert.That(epicReport1.Stage, Is.Not.Null);
            Assert.That(epicReport1.Stage.ContainsKey("In Progress"), Is.True);
            Assert.That(epicReport1.Stage["In Progress"], Is.EqualTo(1));
            Assert.That(epicReport1.Stage.ContainsKey("Done"), Is.True);
            Assert.That(epicReport1.Stage["Done"], Is.EqualTo(1));

            var epicReport2 = result.FirstOrDefault(r => r.Name == epicName2);
            Assert.That(epicReport2, Is.Not.Null);
            Assert.That(epicReport2.Stage, Is.Not.Null);
            Assert.That(epicReport2.Stage.ContainsKey("To Do"), Is.True);
            Assert.That(epicReport2.Stage["To Do"], Is.EqualTo(1));
        }
    }
}
   







 










