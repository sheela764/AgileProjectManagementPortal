import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddepicComponent } from './features/components/addepic/addepic.component';
import { AdduserstoryComponent } from './features/components/CreateUserStory/adduserstory/adduserstory.component';
import { CheckepicIdComponent } from './features/components/CreateUserStory/checkepic-id/checkepic-id.component';
import { GenerateReportComponent } from './features/components/generate-report/generate-report.component';
import { HomeComponent } from './features/components/home/home.component';
import { UserstorieslistComponent } from './features/components/UserStorieslist/userstorieslist/userstorieslist.component';
import { ViewuserstorieslistComponent } from './features/components/UserStorieslist/viewuserstorieslist/viewuserstorieslist.component';
import { UpdateuserstoryComponent } from './features/components/ViewAndUpdateUserStory/updateuserstory/updateuserstory.component';

const routes: Routes = [{
    path: 'home',
    component: HomeComponent
},
  {
  path: 'addepic',
  component: AddepicComponent
},{
   path: 'adduserstory',
   component: CheckepicIdComponent
},{
  path: 'adduserstory/:epicid',
  component: AdduserstoryComponent
},{
  path: 'userstorieslist',
  component: UserstorieslistComponent
},{
  path: 'userstorieslist/:id',
  component: ViewuserstorieslistComponent
},{
  path: 'userstorydetails',
  component: UpdateuserstoryComponent
},{
  path: 'generatereport',
  component: GenerateReportComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
