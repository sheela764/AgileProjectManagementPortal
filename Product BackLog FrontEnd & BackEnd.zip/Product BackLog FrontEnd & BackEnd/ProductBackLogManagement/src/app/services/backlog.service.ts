import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { AddEpic } from '../models/epic.model';
import { Report } from '../models/report.model';
import { UpdateUserStoryRequest } from '../models/update-userstory-request.model';
import { UserStories } from '../models/userstory.model';


@Injectable({
  providedIn: 'root'
})
export class BacklogService {

  constructor(private http: HttpClient) { }

  AddEpic(model: AddEpic): Observable<void> {
    return this.http.post<void>('https://localhost:7280/api/Project', model);
  }

  getEpicDetails(id: number): Observable<AddEpic> {
    return this.http.get<AddEpic>(`https://localhost:7280/api/Project/${id}, Name=GetEpicdetails`);
  }

  AddUserStory(epicId: number, model: UserStories): Observable<void> {
    return this.http.post<void>(`https://localhost:7280/api/Project/${epicId},Name=AddUserStory`, model);
  }

  getUserStoryListByDeveloperId(AssignedDeveloperId: string): Observable<UserStories[]> {
    return this.http.get<UserStories[]>(`https://localhost:7280/api/Project/${AssignedDeveloperId}, Name=GetUserStoryByDevId`);
  }

  getUserStoryByUserId(id: number): Observable<UserStories> {
    return this.http.get<UserStories>(`https://localhost:7280/api/Project/${id}, Name=GetUserStoryById`);
  }

  updateuserstory(id: number, updateUserStoryRequest: UpdateUserStoryRequest): Observable<UserStories> {
    return this.http.put<UserStories>(`https://localhost:7280/api/Project/${id}`, updateUserStoryRequest)
  }

  getReport(ProjectCode: number): Observable<Report> {
    return this.http.get<Report>(`https://localhost:7280/api/Project/${ProjectCode}, Name=GetReportByProjectCode`)
  }

}


